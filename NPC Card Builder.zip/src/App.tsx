import {
  useState, useEffect, useRef, useCallback, useMemo,
} from "react";
import { HexColorPicker } from "react-colorful";
import { v4 as uuidv4 } from "uuid";
import type {
  AppState, Skill, SkillCategory, FrequencyType,
  CardSkillEntry, DamageType, CreatureType,
  CreatureRef, BaseAttack, AttackType, NPCCard, TextFormat,
} from "./types";
import { loadState, saveState, seedState } from "./store";

// ─── Helpers ─────────────────────────────────────────────────────────────────

function applyFmt(fmt?: TextFormat): React.CSSProperties {
  if (!fmt) return {};
  return {
    color: fmt.color,
    fontFamily: fmt.fontFamily,
    fontWeight: fmt.bold ? "bold" : "normal",
    fontStyle: fmt.italic ? "italic" : "normal",
    textDecoration: fmt.underline ? "underline" : "none",
    fontSize: fmt.fontSize ? `${fmt.fontSize}px` : undefined,
  };
}

function freqLabel(f: FrequencyType): string {
  switch (f.kind) {
    case "uses":    return `x ${f.count}`;
    case "con":     return `x ${f.seconds} sec Con`;
    case "cd":      return `x ${f.seconds} sec CD`;
    case "other":   return f.text;
    case "passive": return "Passive";
  }
}

function defaultFmt(): TextFormat {
  return { color: "#e8dcc8", fontFamily: "serif", bold: false, italic: false, underline: false };
}

function emptyCard(): NPCCard {
  return {
    id: uuidv4(), name: "", body: 50, armor: 0,
    creatureTypeIds: [], description: "", skills: [],
    tags: [], createdAt: Date.now(), updatedAt: Date.now(),
  };
}

function defaultFreq(category: SkillCategory): FrequencyType {
  if (category === "PASSIVE") return { kind: "passive" };
  return { kind: "uses", count: 3 };
}

// Paste text at cursor in the currently focused textarea/input
function pasteAtCursor(text: string) {
  const el = document.activeElement as HTMLTextAreaElement | HTMLInputElement | null;
  if (!el || (el.tagName !== "TEXTAREA" && el.tagName !== "INPUT")) return false;
  const start = el.selectionStart ?? el.value.length;
  const end   = el.selectionEnd ?? start;
  const before = el.value.slice(0, start);
  const after  = el.value.slice(end);
  // Trigger React synthetic onChange via native setter
  const proto = el.tagName === "TEXTAREA"
    ? window.HTMLTextAreaElement.prototype
    : window.HTMLInputElement.prototype;
  const setter = Object.getOwnPropertyDescriptor(proto, "value")?.set;
  if (setter) {
    setter.call(el, before + text + after);
    el.dispatchEvent(new Event("input", { bubbles: true }));
  }
  requestAnimationFrame(() => {
    el.selectionStart = el.selectionEnd = start + text.length;
    el.focus();
  });
  return true;
}

// ─── Shared style atoms ───────────────────────────────────────────────────────

const inputBase: React.CSSProperties = {
  background: "#0d0b08", border: "1px solid #4a3f2e", borderRadius: 6,
  color: "#e8dcc8", padding: "6px 10px", fontFamily: "serif",
  fontSize: 14, width: "100%", outline: "none",
};
const inputSm: React.CSSProperties = {
  ...inputBase, width: "auto", padding: "3px 6px", fontSize: 12,
};
const toggleBtn: React.CSSProperties = {
  border: "1px solid #4a3f2e", borderRadius: 4, color: "#c8a96e",
  width: 28, height: 28, cursor: "pointer", fontSize: 13,
};
const btnPrimary: React.CSSProperties = {
  background: "linear-gradient(135deg, #5c3d11 0%, #8b5e1a 100%)",
  border: "1px solid #c8a96e", borderRadius: 6, color: "#f0deb0",
  padding: "7px 16px", cursor: "pointer", fontFamily: "'Cinzel', serif",
  fontSize: 13, letterSpacing: "0.05em",
};
const btnGhost: React.CSSProperties = {
  background: "transparent", border: "1px solid #4a3f2e", borderRadius: 6,
  color: "#9a8a6a", padding: "5px 12px", cursor: "pointer",
  fontFamily: "serif", fontSize: 12,
};
const btnDanger: React.CSSProperties = {
  background: "#2a1010", border: "1px solid #8b3030", borderRadius: 6,
  color: "#e07070", padding: "4px 10px", cursor: "pointer", fontSize: 12,
};
const btnPaste: React.CSSProperties = {
  background: "#0d1a0d", border: "1px solid #3a6a3a", borderRadius: 5,
  color: "#7aba7a", padding: "3px 9px", cursor: "pointer", fontSize: 11,
  fontFamily: "'Cinzel', serif", letterSpacing: "0.04em",
  whiteSpace: "nowrap" as const,
};
const panelCard: React.CSSProperties = {
  background: "linear-gradient(160deg, #1c1510 0%, #12100e 100%)",
  border: "1px solid #3a2f20", borderRadius: 10, padding: 18, marginBottom: 14,
};
const sectionTitle: React.CSSProperties = {
  fontFamily: "'Cinzel', serif", color: "#c8a96e", fontSize: 11,
  letterSpacing: "0.15em", textTransform: "uppercase" as const,
  marginBottom: 8, borderBottom: "1px solid #3a2f20", paddingBottom: 6,
};
const FONT_OPTS = [
  { label: "Serif",        value: "serif" },
  { label: "Sans",         value: "sans-serif" },
  { label: "Mono",         value: "monospace" },
  { label: "Cinzel",       value: "'Cinzel', serif" },
  { label: "Uncial",       value: "'Uncial Antiqua', cursive" },
  { label: "IM Fell",      value: "'IM Fell English', serif" },
];

// ─── Color Picker Popover ─────────────────────────────────────────────────────

function ColorPopover({ value, onChange }: { value: string; onChange: (c: string) => void }) {
  const [open, setOpen] = useState(false);
  const ref = useRef<HTMLDivElement>(null);
  useEffect(() => {
    const h = (e: MouseEvent) => {
      if (ref.current && !ref.current.contains(e.target as Node)) setOpen(false);
    };
    document.addEventListener("mousedown", h);
    return () => document.removeEventListener("mousedown", h);
  }, []);
  return (
    <div ref={ref} style={{ position: "relative", display: "inline-block" }}>
      <button onClick={() => setOpen(o => !o)}
        style={{ width: 26, height: 26, borderRadius: 4, background: value, border: "2px solid #4a3f2e", cursor: "pointer" }} />
      {open && (
        <div style={{ position: "absolute", zIndex: 1000, top: 32, left: 0, background: "#1a1410", border: "1px solid #4a3f2e", borderRadius: 8, padding: 8 }}>
          <HexColorPicker color={value} onChange={onChange} />
          <input style={{ marginTop: 6, width: "100%", background: "#0d0b08", border: "1px solid #4a3f2e", borderRadius: 4, color: "#e8dcc8", padding: "2px 6px", fontFamily: "monospace", fontSize: 12 }}
            value={value} onChange={e => onChange(e.target.value)} />
        </div>
      )}
    </div>
  );
}

// ─── Format Editor ────────────────────────────────────────────────────────────

function FormatEditor({ fmt, onChange, label }: { fmt: TextFormat; onChange: (f: TextFormat) => void; label: string }) {
  const set = (p: Partial<TextFormat>) => onChange({ ...fmt, ...p });
  return (
    <div style={{ display: "flex", alignItems: "center", gap: 8, flexWrap: "wrap", padding: "5px 0" }}>
      <span style={{ color: "#9a8a6a", fontSize: 11, minWidth: 70 }}>{label}</span>
      <ColorPopover value={fmt.color} onChange={c => set({ color: c })} />
      <select value={fmt.fontFamily} onChange={e => set({ fontFamily: e.target.value })} style={inputSm}>
        {FONT_OPTS.map(o => <option key={o.value} value={o.value}>{o.label}</option>)}
      </select>
      <button onClick={() => set({ bold: !fmt.bold })} style={{ ...toggleBtn, fontWeight: "bold", background: fmt.bold ? "#4a3f2e" : "#1a1410" }}>B</button>
      <button onClick={() => set({ italic: !fmt.italic })} style={{ ...toggleBtn, fontStyle: "italic", background: fmt.italic ? "#4a3f2e" : "#1a1410" }}>I</button>
      <button onClick={() => set({ underline: !fmt.underline })} style={{ ...toggleBtn, textDecoration: "underline", background: fmt.underline ? "#4a3f2e" : "#1a1410" }}>U</button>
    </div>
  );
}

// ─── Frequency Editor (inline, for card-level use) ───────────────────────────

function FreqEditor({ freq, onChange }: { freq: FrequencyType; onChange: (f: FrequencyType) => void }) {
  const kind = freq.kind;
  return (
    <div style={{ display: "flex", gap: 6, alignItems: "center", flexWrap: "wrap" }}>
      <select value={kind} style={inputSm}
        onChange={e => {
          const k = e.target.value as FrequencyType["kind"];
          if (k === "uses")    onChange({ kind: "uses", count: 3 });
          else if (k === "con") onChange({ kind: "con", seconds: 10 });
          else if (k === "cd")  onChange({ kind: "cd", seconds: 3 });
          else if (k === "other") onChange({ kind: "other", text: "" });
          else onChange({ kind: "passive" });
        }}>
        <option value="uses">x [uses]</option>
        <option value="con">x [n] sec Con</option>
        <option value="cd">x [n] sec CD</option>
        <option value="other">Other</option>
        <option value="passive">Passive</option>
      </select>
      {kind === "uses" && (
        <input type="number" style={{ ...inputSm, width: 52 }}
          value={(freq as { kind: "uses"; count: number }).count}
          onChange={e => onChange({ kind: "uses", count: Number(e.target.value) })} />
      )}
      {kind === "con" && (
        <>
          <input type="number" style={{ ...inputSm, width: 52 }}
            value={(freq as { kind: "con"; seconds: number }).seconds}
            onChange={e => onChange({ kind: "con", seconds: Number(e.target.value) })} />
          <span style={{ color: "#9a8a6a", fontSize: 11 }}>sec Con</span>
        </>
      )}
      {kind === "cd" && (
        <>
          <input type="number" style={{ ...inputSm, width: 52 }}
            value={(freq as { kind: "cd"; seconds: number }).seconds}
            onChange={e => onChange({ kind: "cd", seconds: Number(e.target.value) })} />
          <span style={{ color: "#9a8a6a", fontSize: 11 }}>sec CD</span>
        </>
      )}
      {kind === "other" && (
        <input style={{ ...inputSm, width: 150 }}
          value={(freq as { kind: "other"; text: string }).text}
          onChange={e => onChange({ kind: "other", text: e.target.value })}
          placeholder="Custom frequency…" />
      )}
    </div>
  );
}

// ─── Skill Badge ──────────────────────────────────────────────────────────────

function SkillBadge({ category }: { category: SkillCategory }) {
  const colors: Record<SkillCategory, string> = {
    TAG: "#78909c", SPELL: "#7e57c2", TALENT: "#c8a96e", PASSIVE: "#5a8a5a",
  };
  return (
    <span style={{ fontSize: 9, fontFamily: "'Cinzel', serif", letterSpacing: "0.1em",
      border: `1px solid ${colors[category]}`, borderRadius: 3, color: colors[category],
      padding: "1px 5px", marginLeft: 6, verticalAlign: "middle" }}>
      {category}
    </span>
  );
}

// ─── Skill Row (bank display) ─────────────────────────────────────────────────

function SkillRow({
  skill, onEdit, onDelete, selectable, selected, onToggle,
}: {
  skill: Skill; onEdit?: () => void; onDelete?: () => void;
  selectable?: boolean; selected?: boolean; onToggle?: () => void;
}) {
  return (
    <div onClick={selectable ? onToggle : undefined}
      style={{ background: selected ? "rgba(74,63,46,0.4)" : "rgba(255,255,255,0.02)",
        border: `1px solid ${selected ? "#c8a96e" : "#3a2f20"}`, borderRadius: 8,
        padding: "10px 14px", marginBottom: 8, cursor: selectable ? "pointer" : "default",
        transition: "border-color 0.15s" }}>
      <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between" }}>
        <div style={{ display: "flex", alignItems: "center", gap: 6, flexWrap: "wrap" }}>
          <span style={{ ...applyFmt(skill.nameFormat), fontSize: 15 }}>{skill.name}</span>
          <SkillBadge category={skill.category} />
          {skill.domain && (
            <span style={{ color: "#7e9a7e", fontSize: 10, fontStyle: "italic" }}>[{skill.domain}]</span>
          )}
        </div>
        {(onEdit || onDelete) && (
          <div style={{ display: "flex", gap: 6 }}>
            {onEdit && (
              <button style={{ ...btnGhost }} onClick={e => { e.stopPropagation(); onEdit(); }}>Edit</button>
            )}
            {onDelete && (
              <button style={btnDanger} onClick={e => { e.stopPropagation(); onDelete(); }}>✕</button>
            )}
          </div>
        )}
      </div>
      <p style={{ ...applyFmt(skill.rulesFormat), fontSize: 12, marginTop: 4, lineHeight: 1.5 }}>
        {skill.rulesText}
      </p>
    </div>
  );
}

// ─── Skills Bank ──────────────────────────────────────────────────────────────

function emptySkill(): Skill {
  return {
    id: uuidv4(), name: "", category: "TALENT", domain: "",
    rulesText: "",
    nameFormat: { color: "#c8a96e", fontFamily: "'Cinzel', serif", bold: true, italic: false, underline: false },
    rulesFormat: defaultFmt(),
  };
}

function SkillForm({ initial, onSave, onCancel }: {
  initial?: Skill; onSave: (s: Skill) => void; onCancel: () => void;
}) {
  const [skill, setSkill] = useState<Skill>(initial ? { ...initial } : emptySkill());
  const set = (p: Partial<Skill>) => setSkill(s => ({ ...s, ...p }));
  const hasDomain = skill.category === "SPELL" || skill.category === "TALENT";
  return (
    <div style={panelCard}>
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10, marginBottom: 10 }}>
        <div>
          <label style={sectionTitle}>Skill Name</label>
          <input style={inputBase} value={skill.name} onChange={e => set({ name: e.target.value })} placeholder="e.g. SUBDUE" />
        </div>
        <div>
          <label style={sectionTitle}>Category</label>
          <select style={inputBase} value={skill.category}
            onChange={e => set({ category: e.target.value as SkillCategory })}>
            {(["TAG","SPELL","TALENT","PASSIVE"] as SkillCategory[]).map(c =>
              <option key={c} value={c}>{c}</option>)}
          </select>
        </div>
      </div>
      {hasDomain && (
        <div style={{ marginBottom: 10 }}>
          <label style={sectionTitle}>Domain</label>
          <input style={inputBase} value={skill.domain ?? ""} onChange={e => set({ domain: e.target.value })} placeholder="e.g. Combat, Evocation…" />
        </div>
      )}
      <div style={{ marginBottom: 10 }}>
        <label style={sectionTitle}>Rules Text</label>
        <textarea style={{ ...inputBase, minHeight: 80, resize: "vertical" }} value={skill.rulesText}
          onChange={e => set({ rulesText: e.target.value })} placeholder="Describe what this skill does…" />
      </div>
      <div style={{ marginBottom: 14 }}>
        <label style={sectionTitle}>Text Formatting</label>
        <FormatEditor fmt={skill.nameFormat ?? defaultFmt()} onChange={f => set({ nameFormat: f })} label="Skill Name" />
        <FormatEditor fmt={skill.rulesFormat ?? defaultFmt()} onChange={f => set({ rulesFormat: f })} label="Rules Text" />
      </div>
      <div style={{ display: "flex", gap: 10 }}>
        <button style={btnPrimary} onClick={() => { if (!skill.name.trim()) return; onSave(skill); }}>Save Skill</button>
        <button style={btnDanger} onClick={onCancel}>Cancel</button>
      </div>
    </div>
  );
}

function SkillsBank({ skills, onUpdate }: { skills: Skill[]; onUpdate: (s: Skill[]) => void }) {
  const [query, setQuery] = useState("");
  const [filterCat, setFilterCat] = useState<SkillCategory | "ALL">("ALL");
  const [editing, setEditing] = useState<string | null>(null);
  const [adding, setAdding] = useState(false);

  const filtered = useMemo(() => {
    const q = query.toLowerCase();
    return skills.filter(s => {
      const catOk = filterCat === "ALL" || s.category === filterCat;
      const textOk = !q || s.name.toLowerCase().includes(q) || s.rulesText.toLowerCase().includes(q) || (s.domain ?? "").toLowerCase().includes(q);
      return catOk && textOk;
    });
  }, [skills, query, filterCat]);

  const save = (s: Skill) => {
    const exists = skills.find(x => x.id === s.id);
    onUpdate(exists ? skills.map(x => x.id === s.id ? s : x) : [...skills, s]);
    setEditing(null); setAdding(false);
  };

  return (
    <div>
      <div style={{ display: "flex", gap: 10, marginBottom: 14, flexWrap: "wrap" }}>
        <input style={{ ...inputBase, flex: 1, minWidth: 180 }} placeholder="Search — name, domain, rules text…"
          value={query} onChange={e => setQuery(e.target.value)} />
        <select style={inputSm} value={filterCat} onChange={e => setFilterCat(e.target.value as SkillCategory | "ALL")}>
          <option value="ALL">All Types</option>
          {(["TAG","SPELL","TALENT","PASSIVE"] as SkillCategory[]).map(c => <option key={c} value={c}>{c}</option>)}
        </select>
        <button style={btnPrimary} onClick={() => setAdding(true)}>+ New Skill</button>
      </div>
      {adding && <SkillForm onSave={save} onCancel={() => setAdding(false)} />}
      {filtered.map(s => editing === s.id
        ? <SkillForm key={s.id} initial={s} onSave={save} onCancel={() => setEditing(null)} />
        : <SkillRow key={s.id} skill={s} onEdit={() => setEditing(s.id)} onDelete={() => onUpdate(skills.filter(x => x.id !== s.id))} />
      )}
      {filtered.length === 0 && !adding && (
        <p style={{ color: "#5a4a3a", textAlign: "center", padding: 40, fontStyle: "italic" }}>
          No skills found. Create one above.
        </p>
      )}
    </div>
  );
}

// ─── Damage Types Bank ────────────────────────────────────────────────────────

function DamageTypesBank({ types, onUpdate }: { types: DamageType[]; onUpdate: (t: DamageType[]) => void }) {
  const [adding, setAdding] = useState(false);
  const [name, setName] = useState("");
  const [fmt, setFmt] = useState<TextFormat>({ color: "#e57373", fontFamily: "'Cinzel', serif", bold: true, italic: false, underline: false });
  const [editId, setEditId] = useState<string | null>(null);

  const reset = () => { setAdding(false); setEditId(null); setName(""); setFmt({ color: "#e57373", fontFamily: "'Cinzel', serif", bold: true, italic: false, underline: false }); };

  const save = () => {
    if (!name.trim()) return;
    if (editId) {
      onUpdate(types.map(t => t.id === editId ? { ...t, name, format: fmt } : t));
    } else {
      onUpdate([...types, { id: uuidv4(), name, format: fmt }]);
    }
    reset();
  };

  return (
    <div>
      <div style={{ display: "flex", justifyContent: "flex-end", marginBottom: 12 }}>
        <button style={btnPrimary} onClick={() => setAdding(true)}>+ New Damage Type</button>
      </div>
      {adding && (
        <div style={panelCard}>
          <div style={{ marginBottom: 10 }}>
            <label style={sectionTitle}>Name</label>
            <input style={inputBase} value={name} onChange={e => setName(e.target.value)} placeholder="e.g. Fire" />
          </div>
          <FormatEditor fmt={fmt} onChange={setFmt} label="Style" />
          <div style={{ display: "flex", gap: 8, marginTop: 10 }}>
            <button style={btnPrimary} onClick={save}>Save</button>
            <button style={btnDanger} onClick={reset}>Cancel</button>
          </div>
        </div>
      )}
      <div style={{ display: "flex", flexWrap: "wrap", gap: 10 }}>
        {types.map(t => (
          <div key={t.id} style={{ background: "#1a1410", border: "1px solid #3a2f20", borderRadius: 8, padding: "8px 14px", display: "flex", alignItems: "center", gap: 10 }}>
            <span style={applyFmt(t.format)}>{t.name}</span>
            <button style={{ ...btnGhost, padding: "2px 6px" }} onClick={() => { setEditId(t.id); setName(t.name); setFmt(t.format); setAdding(true); }}>Edit</button>
            <button style={{ ...btnDanger, padding: "2px 6px" }} onClick={() => onUpdate(types.filter(x => x.id !== t.id))}>✕</button>
          </div>
        ))}
      </div>
    </div>
  );
}

// ─── Creature Types Bank ──────────────────────────────────────────────────────

function CreatureRefEditor({ refEntry, onUpdate, onDelete, damageTypes, skills }: {
  refEntry: CreatureRef;
  onUpdate: (r: CreatureRef) => void; onDelete: () => void;
  damageTypes: DamageType[]; skills: Skill[];
}) {
  return (
    <div style={{ display: "flex", gap: 6, alignItems: "center", marginBottom: 4 }}>
      <select value={refEntry.kind} style={inputSm}
        onChange={e => {
          const k = e.target.value as CreatureRef["kind"];
          if (k === "damage") onUpdate({ kind: "damage", damageTypeId: damageTypes[0]?.id ?? "" });
          else if (k === "skill") onUpdate({ kind: "skill", skillId: skills[0]?.id ?? "" });
          else onUpdate({ kind: "rp", text: "" });
        }}>
        <option value="damage">Damage Type</option>
        <option value="skill">Skill</option>
        <option value="rp">RP Text</option>
      </select>
      {refEntry.kind === "damage" && (
        <select style={inputSm} value={refEntry.damageTypeId}
          onChange={e => onUpdate({ kind: "damage", damageTypeId: e.target.value })}>
          {damageTypes.map(d => <option key={d.id} value={d.id}>{d.name}</option>)}
        </select>
      )}
      {refEntry.kind === "skill" && (
        <select style={inputSm} value={refEntry.skillId}
          onChange={e => onUpdate({ kind: "skill", skillId: e.target.value })}>
          {skills.map(s => <option key={s.id} value={s.id}>{s.name}</option>)}
        </select>
      )}
      {refEntry.kind === "rp" && (
        <input style={{ ...inputSm, width: 140 }} value={refEntry.text}
          onChange={e => onUpdate({ kind: "rp", text: e.target.value })} placeholder="RP description…" />
      )}
      <button style={{ ...btnDanger, padding: "2px 6px" }} onClick={onDelete}>✕</button>
    </div>
  );
}

function CreatureTypeForm({ initial, onSave, onCancel, damageTypes, skills }: {
  initial?: CreatureType; onSave: (ct: CreatureType) => void; onCancel: () => void;
  damageTypes: DamageType[]; skills: Skill[];
}) {
  const blank: CreatureType = {
    id: uuidv4(), name: "",
    format: { color: "#c8a96e", fontFamily: "'Cinzel', serif", bold: false, italic: false, underline: false },
    weaknesses: [], resistances: [], immunities: [], baseAttacks: [],
  };
  const [ct, setCt] = useState<CreatureType>(initial ? { ...initial, weaknesses: [...initial.weaknesses], resistances: [...initial.resistances], immunities: [...initial.immunities], baseAttacks: [...initial.baseAttacks] } : blank);
  const set = (p: Partial<CreatureType>) => setCt(c => ({ ...c, ...p }));

  const addRef = (section: "weaknesses" | "resistances" | "immunities") => {
    const r: CreatureRef = damageTypes.length > 0 ? { kind: "damage", damageTypeId: damageTypes[0].id } : { kind: "rp", text: "" };
    set({ [section]: [...ct[section], r] });
  };
  const updateRef = (section: "weaknesses" | "resistances" | "immunities", i: number, r: CreatureRef) =>
    set({ [section]: ct[section].map((x, idx) => idx === i ? r : x) });
  const deleteRef = (section: "weaknesses" | "resistances" | "immunities", i: number) =>
    set({ [section]: ct[section].filter((_, idx) => idx !== i) });

  const addAttack = () =>
    set({ baseAttacks: [...ct.baseAttacks, { id: uuidv4(), weaponName: "", damage: 3, damageTypeId: damageTypes[0]?.id ?? "", attackType: "Melee" }] });
  const updateAttack = (i: number, p: Partial<BaseAttack>) =>
    set({ baseAttacks: ct.baseAttacks.map((a, idx) => idx === i ? { ...a, ...p } : a) });
  const deleteAttack = (i: number) =>
    set({ baseAttacks: ct.baseAttacks.filter((_, idx) => idx !== i) });

  const sectionBlock = (label: string, colorHex: string, key: "weaknesses" | "resistances" | "immunities") => (
    <div style={{ marginBottom: 12 }}>
      <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 6 }}>
        <span style={{ color: colorHex, fontFamily: "'Cinzel', serif", fontSize: 11, letterSpacing: "0.1em" }}>{label}</span>
        <button style={{ ...btnGhost, padding: "2px 8px", fontSize: 11 }} onClick={() => addRef(key)}>+ Add</button>
      </div>
      {ct[key].map((r, i) => (
        <CreatureRefEditor key={i} refEntry={r}
          onUpdate={r2 => updateRef(key, i, r2)}
          onDelete={() => deleteRef(key, i)}
          damageTypes={damageTypes} skills={skills} />
      ))}
    </div>
  );

  return (
    <div style={panelCard}>
      <div style={{ display: "grid", gridTemplateColumns: "1fr auto", gap: 10, marginBottom: 12 }}>
        <div>
          <label style={sectionTitle}>Name</label>
          <input style={inputBase} value={ct.name} onChange={e => set({ name: e.target.value })} placeholder="e.g. Demon" />
        </div>
      </div>
      <div style={{ marginBottom: 12 }}>
        <label style={sectionTitle}>Display Format</label>
        <FormatEditor fmt={ct.format} onChange={f => set({ format: f })} label="Name Style" />
      </div>

      <label style={sectionTitle}>Weaknesses / Resistances / Immunities</label>
      {sectionBlock("WEAKNESSES", "#e57373", "weaknesses")}
      {sectionBlock("RESISTANCES", "#64b5f6", "resistances")}
      {sectionBlock("IMMUNITIES", "#aed581", "immunities")}

      <label style={sectionTitle}>Base Attacks</label>
      {ct.baseAttacks.map((a, i) => (
        <div key={a.id} style={{ display: "flex", gap: 6, alignItems: "center", marginBottom: 6, flexWrap: "wrap" }}>
          <select style={inputSm} value={a.attackType} onChange={e => updateAttack(i, { attackType: e.target.value as AttackType })}>
            {(["Melee","Ranged","Phokus"] as AttackType[]).map(t => <option key={t} value={t}>{t}</option>)}
          </select>
          <input style={{ ...inputSm, width: 120 }} value={a.weaponName} onChange={e => updateAttack(i, { weaponName: e.target.value })} placeholder="Weapon name" />
          <input type="number" style={{ ...inputSm, width: 52 }} value={a.damage} onChange={e => updateAttack(i, { damage: Number(e.target.value) })} />
          <select style={inputSm} value={a.damageTypeId} onChange={e => updateAttack(i, { damageTypeId: e.target.value })}>
            {damageTypes.map(d => <option key={d.id} value={d.id}>{d.name}</option>)}
          </select>
          <button style={{ ...btnDanger, padding: "2px 6px" }} onClick={() => deleteAttack(i)}>✕</button>
        </div>
      ))}
      <button style={{ ...btnGhost, marginBottom: 14, fontSize: 11 }} onClick={addAttack}>+ Add Attack</button>

      <div style={{ display: "flex", gap: 10 }}>
        <button style={btnPrimary} onClick={() => { if (!ct.name.trim()) return; onSave(ct); }}>Save Creature Type</button>
        <button style={btnDanger} onClick={onCancel}>Cancel</button>
      </div>
    </div>
  );
}

function CreatureTypesBank({ types, onUpdate, damageTypes, skills }: {
  types: CreatureType[]; onUpdate: (t: CreatureType[]) => void;
  damageTypes: DamageType[]; skills: Skill[];
}) {
  const [editing, setEditing] = useState<string | null>(null);
  const [adding, setAdding] = useState(false);

  const save = (ct: CreatureType) => {
    const exists = types.find(t => t.id === ct.id);
    onUpdate(exists ? types.map(t => t.id === ct.id ? ct : t) : [...types, ct]);
    setEditing(null); setAdding(false);
  };

  return (
    <div>
      <div style={{ display: "flex", justifyContent: "flex-end", marginBottom: 12 }}>
        <button style={btnPrimary} onClick={() => setAdding(true)}>+ New Creature Type</button>
      </div>
      {adding && <CreatureTypeForm onSave={save} onCancel={() => setAdding(false)} damageTypes={damageTypes} skills={skills} />}
      {types.map(t => editing === t.id
        ? <CreatureTypeForm key={t.id} initial={t} onSave={save} onCancel={() => setEditing(null)} damageTypes={damageTypes} skills={skills} />
        : (
          <div key={t.id} style={{ ...panelCard, display: "flex", justifyContent: "space-between", alignItems: "center" }}>
            <div>
              <span style={{ ...applyFmt(t.format), fontSize: 16 }}>{t.name}</span>
              <div style={{ display: "flex", gap: 12, marginTop: 6, fontSize: 11, color: "#9a8a6a" }}>
                <span>Weaknesses: {t.weaknesses.length}</span>
                <span>Resistances: {t.resistances.length}</span>
                <span>Immunities: {t.immunities.length}</span>
                <span>Attacks: {t.baseAttacks.length}</span>
              </div>
            </div>
            <div style={{ display: "flex", gap: 6 }}>
              <button style={btnGhost} onClick={() => setEditing(t.id)}>Edit</button>
              <button style={btnDanger} onClick={() => onUpdate(types.filter(x => x.id !== t.id))}>✕</button>
            </div>
          </div>
        )
      )}
    </div>
  );
}

// ─── Creature Info Side Panel ─────────────────────────────────────────────────

function refLabel(r: CreatureRef, damageTypes: DamageType[], skills: Skill[]): string {
  if (r.kind === "damage") return damageTypes.find(d => d.id === r.damageTypeId)?.name ?? "?";
  if (r.kind === "skill")  return skills.find(s => s.id === r.skillId)?.name ?? "?";
  return r.text;
}

function buildAttackString(a: BaseAttack, damageTypes: DamageType[]): string {
  const dt = damageTypes.find(d => d.id === a.damageTypeId)?.name ?? "Unknown";
  return `${a.attackType}: ${a.weaponName} — ${a.damage} ${dt} damage`;
}

function buildWeaknessString(ct: CreatureType, damageTypes: DamageType[], skills: Skill[]): string {
  const parts = [
    ct.weaknesses.length > 0 ? `WEAK to ${ct.weaknesses.map(r => refLabel(r, damageTypes, skills)).join(", ")}` : "",
    ct.resistances.length > 0 ? `RESISTANT to ${ct.resistances.map(r => refLabel(r, damageTypes, skills)).join(", ")}` : "",
    ct.immunities.length > 0 ? `IMMUNE to ${ct.immunities.map(r => refLabel(r, damageTypes, skills)).join(", ")}` : "",
  ].filter(Boolean);
  return parts.join(". ");
}

function CreatureInfoPanel({ creatureTypes, selectedIds, damageTypes, skills }: {
  creatureTypes: CreatureType[]; selectedIds: string[];
  damageTypes: DamageType[]; skills: Skill[];
}) {
  const selected = selectedIds.map(id => creatureTypes.find(c => c.id === id)).filter(Boolean) as CreatureType[];
  if (selected.length === 0) return null;

  return (
    <div style={{
      background: "linear-gradient(160deg, #0f1a0f 0%, #0d120a 100%)",
      border: "1px solid #2a4a2a", borderRadius: 10, padding: 16,
      marginTop: 14,
    }}>
      <div style={{ ...sectionTitle, color: "#7aba7a", borderColor: "#2a4a2a" }}>
        Creature Type Reference
        <span style={{ color: "#3a6a3a", fontSize: 10, marginLeft: 6, letterSpacing: 0 }}>
          — click a field, then press Paste to insert text at cursor
        </span>
      </div>
      {selected.map(ct => (
        <div key={ct.id} style={{ marginBottom: 16, borderBottom: "1px solid #1a3a1a", paddingBottom: 14 }}>
          <div style={{ ...applyFmt(ct.format), fontSize: 15, marginBottom: 8 }}>{ct.name}</div>

          {(ct.weaknesses.length > 0 || ct.resistances.length > 0 || ct.immunities.length > 0) && (
            <div style={{ marginBottom: 8 }}>
              <div style={{ color: "#5a8a5a", fontSize: 10, letterSpacing: "0.1em", fontFamily: "'Cinzel', serif", marginBottom: 4 }}>TRAITS</div>
              {[
                { label: "WEAK TO", items: ct.weaknesses, color: "#e57373" },
                { label: "RESISTANT TO", items: ct.resistances, color: "#64b5f6" },
                { label: "IMMUNE TO", items: ct.immunities, color: "#aed581" },
              ].map(({ label, items, color }) => items.length > 0 && (
                <div key={label} style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 4, flexWrap: "wrap" }}>
                  <span style={{ color, fontSize: 10, fontFamily: "'Cinzel', serif", minWidth: 80 }}>{label}</span>
                  <div style={{ display: "flex", gap: 4, flexWrap: "wrap" }}>
                    {items.map((r, i) => {
                      const txt = refLabel(r, damageTypes, skills);
                      return (
                        <span key={i} style={{ display: "flex", alignItems: "center", gap: 4 }}>
                          <span style={{ color: "#c8c8c8", fontSize: 12 }}>{txt}</span>
                          <button style={btnPaste}
                            onMouseDown={e => { e.preventDefault(); pasteAtCursor(txt); }}>
                            Paste
                          </button>
                        </span>
                      );
                    })}
                  </div>
                  <button style={{ ...btnPaste, background: "#0d1a0a", borderColor: "#2a5a2a" }}
                    onMouseDown={e => {
                      e.preventDefault();
                      const full = `${label}: ${items.map(r => refLabel(r, damageTypes, skills)).join(", ")}`;
                      pasteAtCursor(full);
                    }}>
                    Paste All
                  </button>
                </div>
              ))}
              <div style={{ marginTop: 6 }}>
                <button style={{ ...btnPaste, background: "#0d1a0a", borderColor: "#2a5a2a" }}
                  onMouseDown={e => { e.preventDefault(); pasteAtCursor(buildWeaknessString(ct, damageTypes, skills)); }}>
                  Paste Full Trait Block
                </button>
              </div>
            </div>
          )}

          {ct.baseAttacks.length > 0 && (
            <div>
              <div style={{ color: "#5a8a5a", fontSize: 10, letterSpacing: "0.1em", fontFamily: "'Cinzel', serif", marginBottom: 4 }}>BASE ATTACKS</div>
              {ct.baseAttacks.map(a => {
                const str = buildAttackString(a, damageTypes);
                return (
                  <div key={a.id} style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 4 }}>
                    <span style={{ color: "#c8c8c8", fontSize: 12 }}>{str}</span>
                    <button style={btnPaste} onMouseDown={e => { e.preventDefault(); pasteAtCursor(str); }}>Paste</button>
                  </div>
                );
              })}
              <button style={{ ...btnPaste, marginTop: 4, background: "#0d1a0a", borderColor: "#2a5a2a" }}
                onMouseDown={e => {
                  e.preventDefault();
                  pasteAtCursor(ct.baseAttacks.map(a => buildAttackString(a, damageTypes)).join("\n"));
                }}>
                Paste All Attacks
              </button>
            </div>
          )}
        </div>
      ))}
    </div>
  );
}

// ─── NPC Card Preview ─────────────────────────────────────────────────────────

function CardPreview({ card, skills, creatureTypes }: {
  card: NPCCard; skills: Skill[]; creatureTypes: CreatureType[];
}) {
  const cardSkills = card.skills
    .map(e => ({ entry: e, skill: skills.find(s => s.id === e.skillId) }))
    .filter(x => x.skill) as { entry: CardSkillEntry; skill: Skill }[];

  const types = card.creatureTypeIds
    .map(id => creatureTypes.find(c => c.id === id)).filter(Boolean) as CreatureType[];

  return (
    <div style={{
      width: 460, minHeight: 600,
      background: card.backgroundImage
        ? `url(${card.backgroundImage}) center/cover`
        : "linear-gradient(170deg, #1c1208 0%, #0d0b08 60%, #12100a 100%)",
      border: "2px solid #5a4520", borderRadius: 12, padding: 22,
      fontFamily: "serif", position: "relative",
      boxShadow: "0 8px 40px rgba(0,0,0,0.8), inset 0 0 60px rgba(0,0,0,0.5)",
      flexShrink: 0,
    }}>
      {card.backgroundImage && (
        <div style={{ position: "absolute", inset: 0, background: "rgba(10,8,5,0.74)", borderRadius: 10 }} />
      )}
      <div style={{ position: "relative" }}>
        {/* Header */}
        <h1 style={{ fontFamily: "'Cinzel', serif", fontSize: 30, fontWeight: 700, color: "#f0deb0", margin: 0, lineHeight: 1.1, textShadow: "2px 2px 6px rgba(0,0,0,0.9)" }}>
          {card.name || "Unnamed NPC"}
        </h1>
        {types.length > 0 && (
          <div style={{ display: "flex", gap: 5, flexWrap: "wrap", marginTop: 3 }}>
            {types.map(t => <span key={t.id} style={{ ...applyFmt(t.format), fontSize: 10 }}>[{t.name}]</span>)}
          </div>
        )}
        <div style={{ fontFamily: "'Cinzel', serif", color: "#c8a96e", fontSize: 14, marginTop: 5, borderBottom: "1px solid #5a4520", paddingBottom: 10 }}>
          Body : {card.body} &nbsp; Armor : {card.armor}
        </div>

        {/* Two-column body */}
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 16, marginTop: 14 }}>
          {/* Left — Lore */}
          <div>
            {card.description && (
              <p style={{ color: "#d4c4a4", fontSize: 11.5, lineHeight: 1.7, margin: 0 }}>
                {card.description}
              </p>
            )}
          </div>

          {/* Right — Skills */}
          <div style={{ borderLeft: "1px solid #3a2f20", paddingLeft: 14 }}>
            {cardSkills.map(({ entry, skill }) => (
              <div key={skill.id} style={{ marginBottom: 11 }}>
                <div style={{ display: "flex", alignItems: "baseline", gap: 6, flexWrap: "wrap", marginBottom: 2 }}>
                  <span style={{ ...applyFmt(skill.nameFormat), fontSize: 13, letterSpacing: "0.04em" }}>
                    {skill.name}
                  </span>
                  {skill.category !== "PASSIVE" && (
                    <span style={{ fontFamily: "'Cinzel', serif", color: "#9a8a6a", fontSize: 11 }}>
                      {freqLabel(entry.frequency)}
                    </span>
                  )}
                  {skill.category === "PASSIVE" && (
                    <span style={{ fontStyle: "italic", color: "#7a9a7a", fontSize: 10 }}>Passive</span>
                  )}
                </div>
                <p style={{ ...applyFmt(skill.rulesFormat), fontSize: 10.5, lineHeight: 1.5, margin: 0 }}>
                  {skill.rulesText}
                </p>
              </div>
            ))}
            {cardSkills.length === 0 && (
              <p style={{ color: "#3a2f20", fontSize: 11, fontStyle: "italic" }}>No skills added.</p>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

// ─── Card Builder ─────────────────────────────────────────────────────────────

function CardBuilder({ state, onSave, editCard, onClear }: {
  state: AppState; onSave: (card: NPCCard) => void;
  editCard?: NPCCard; onClear: () => void;
}) {
  const [card, setCard] = useState<NPCCard>(editCard ?? emptyCard());
  const [skillSearch, setSkillSearch] = useState("");
  const [skillFilter, setSkillFilter] = useState<SkillCategory | "ALL">("ALL");
  const [bgPreview, setBgPreview] = useState<string | undefined>(card.backgroundImage);
  const fileRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (editCard) { setCard({ ...editCard }); setBgPreview(editCard.backgroundImage); }
  }, [editCard?.id]);

  const set = (p: Partial<NPCCard>) => setCard(c => ({ ...c, ...p }));

  // Toggle skill: if not present add with default freq; if present, remove
  const toggleSkill = (skillId: string) => {
    const exists = card.skills.find(e => e.skillId === skillId);
    if (exists) {
      set({ skills: card.skills.filter(e => e.skillId !== skillId) });
    } else {
      const skill = state.skills.find(s => s.id === skillId);
      set({ skills: [...card.skills, { skillId, frequency: defaultFreq(skill?.category ?? "TALENT") }] });
    }
  };

  const updateFreq = (skillId: string, frequency: FrequencyType) =>
    set({ skills: card.skills.map(e => e.skillId === skillId ? { ...e, frequency } : e) });

  const toggleCreatureType = (id: string) =>
    set({ creatureTypeIds: card.creatureTypeIds.includes(id)
      ? card.creatureTypeIds.filter(x => x !== id)
      : [...card.creatureTypeIds, id] });

  const filteredSkills = useMemo(() => {
    const q = skillSearch.toLowerCase();
    return state.skills.filter(s => {
      const catOk = skillFilter === "ALL" || s.category === skillFilter;
      const textOk = !q || s.name.toLowerCase().includes(q) || s.rulesText.toLowerCase().includes(q) || (s.domain ?? "").toLowerCase().includes(q);
      return catOk && textOk;
    });
  }, [state.skills, skillSearch, skillFilter]);

  const handleBgUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = ev => {
      const url = ev.target?.result as string;
      setBgPreview(url); set({ backgroundImage: url });
    };
    reader.readAsDataURL(file);
  };

  return (
    <div style={{ display: "flex", gap: 24, alignItems: "flex-start", flexWrap: "wrap" }}>
      {/* ── Left: Form ── */}
      <div style={{ flex: "1 1 400px", minWidth: 340, maxWidth: 540 }}>

        {/* Identity */}
        <div style={panelCard}>
          <div style={sectionTitle}>Identity</div>
          <div style={{ marginBottom: 10 }}>
            <label style={{ color: "#9a8a6a", fontSize: 11 }}>NPC Name</label>
            <input style={{ ...inputBase, marginTop: 4 }} value={card.name}
              onChange={e => set({ name: e.target.value })} placeholder="e.g. Snail Man" />
          </div>
          <div style={{ display: "flex", gap: 10, marginBottom: 10 }}>
            <div style={{ flex: 1 }}>
              <label style={{ color: "#9a8a6a", fontSize: 11 }}>Body</label>
              <input type="number" style={{ ...inputBase, marginTop: 4 }} value={card.body}
                onChange={e => set({ body: Number(e.target.value) })} />
            </div>
            <div style={{ flex: 1 }}>
              <label style={{ color: "#9a8a6a", fontSize: 11 }}>Armor</label>
              <input type="number" style={{ ...inputBase, marginTop: 4 }} value={card.armor}
                onChange={e => set({ armor: Number(e.target.value) })} />
            </div>
          </div>
          <div style={{ marginBottom: 10 }}>
            <label style={{ color: "#9a8a6a", fontSize: 11 }}>Creature Types</label>
            <div style={{ display: "flex", flexWrap: "wrap", gap: 6, marginTop: 6 }}>
              {state.creatureTypes.map(t => (
                <button key={t.id} onClick={() => toggleCreatureType(t.id)} style={{
                  border: `1px solid ${card.creatureTypeIds.includes(t.id) ? "#c8a96e" : "#3a2f20"}`,
                  background: card.creatureTypeIds.includes(t.id) ? "#2e2010" : "#0d0b08",
                  borderRadius: 4, padding: "3px 10px", cursor: "pointer",
                  ...applyFmt(t.format), fontSize: 12,
                }}>
                  {t.name}
                </button>
              ))}
            </div>
          </div>
          <div>
            <label style={{ color: "#9a8a6a", fontSize: 11 }}>Tags (comma-separated)</label>
            <input style={{ ...inputBase, marginTop: 4 }} value={card.tags.join(", ")}
              onChange={e => set({ tags: e.target.value.split(",").map(t => t.trim()).filter(Boolean) })}
              placeholder="e.g. underdark, empire, elite" />
          </div>
        </div>

        {/* Creature Info Panel */}
        {card.creatureTypeIds.length > 0 && (
          <CreatureInfoPanel
            creatureTypes={state.creatureTypes}
            selectedIds={card.creatureTypeIds}
            damageTypes={state.damageTypes}
            skills={state.skills}
          />
        )}

        {/* Description */}
        <div style={panelCard}>
          <div style={sectionTitle}>Description / Lore</div>
          <textarea style={{ ...inputBase, minHeight: 120, resize: "vertical" }} value={card.description}
            onChange={e => set({ description: e.target.value })}
            placeholder="Background, tactics, roleplay notes… Click here first, then use Paste buttons above." />
        </div>

        {/* Background image */}
        <div style={panelCard}>
          <div style={sectionTitle}>Background Image (transparent PNG / WebP)</div>
          <div style={{ display: "flex", gap: 10, alignItems: "center" }}>
            <button style={btnPrimary} onClick={() => fileRef.current?.click()}>Upload Image</button>
            {bgPreview && <button style={btnDanger} onClick={() => { setBgPreview(undefined); set({ backgroundImage: undefined }); }}>Remove</button>}
            <input ref={fileRef} type="file" accept="image/png,image/webp,image/svg+xml" style={{ display: "none" }} onChange={handleBgUpload} />
          </div>
          {bgPreview && <img src={bgPreview} alt="BG preview" style={{ marginTop: 10, maxWidth: "100%", maxHeight: 100, objectFit: "contain", borderRadius: 6, border: "1px solid #3a2f20" }} />}
        </div>

        {/* Skills picker */}
        <div style={panelCard}>
          <div style={sectionTitle}>Skills</div>
          <div style={{ display: "flex", gap: 8, marginBottom: 10, flexWrap: "wrap" }}>
            <input style={{ ...inputBase, flex: 1, minWidth: 150 }} placeholder="Search skills…"
              value={skillSearch} onChange={e => setSkillSearch(e.target.value)} />
            <select style={inputSm} value={skillFilter} onChange={e => setSkillFilter(e.target.value as SkillCategory | "ALL")}>
              <option value="ALL">All</option>
              {(["TAG","SPELL","TALENT","PASSIVE"] as SkillCategory[]).map(c => <option key={c} value={c}>{c}</option>)}
            </select>
          </div>
          <div style={{ maxHeight: 260, overflowY: "auto", paddingRight: 4 }}>
            {filteredSkills.map(s => (
              <SkillRow key={s.id} skill={s} selectable
                selected={card.skills.some(e => e.skillId === s.id)}
                onToggle={() => toggleSkill(s.id)} />
            ))}
            {filteredSkills.length === 0 && (
              <p style={{ color: "#5a4a3a", fontStyle: "italic", textAlign: "center", padding: 20 }}>
                No skills found. Add skills in the Skills Bank.
              </p>
            )}
          </div>

          {/* Selected skills + per-skill frequency */}
          {card.skills.length > 0 && (
            <div style={{ marginTop: 12, borderTop: "1px solid #3a2f20", paddingTop: 10 }}>
              <p style={sectionTitle}>Selected Skills — Set Frequency</p>
              {card.skills.map(entry => {
                const sk = state.skills.find(s => s.id === entry.skillId);
                if (!sk) return null;
                return (
                  <div key={entry.skillId} style={{ marginBottom: 10, background: "#0d0b08", border: "1px solid #3a2f20", borderRadius: 8, padding: "8px 12px" }}>
                    <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 6 }}>
                      <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
                        <span style={{ ...applyFmt(sk.nameFormat), fontSize: 13 }}>{sk.name}</span>
                        <SkillBadge category={sk.category} />
                      </div>
                      <button style={{ ...btnDanger, padding: "2px 6px", fontSize: 11 }} onClick={() => toggleSkill(entry.skillId)}>✕ Remove</button>
                    </div>
                    {sk.category !== "PASSIVE" ? (
                      <FreqEditor freq={entry.frequency} onChange={f => updateFreq(entry.skillId, f)} />
                    ) : (
                      <span style={{ color: "#5a8a5a", fontSize: 11, fontStyle: "italic" }}>Passive — no frequency</span>
                    )}
                  </div>
                );
              })}
            </div>
          )}
        </div>

        <div style={{ display: "flex", gap: 10 }}>
          <button style={{ ...btnPrimary, fontSize: 14 }} onClick={() => { if (!card.name.trim()) return; onSave({ ...card, updatedAt: Date.now() }); onClear(); }}>
            {editCard ? "Update Card" : "Save Card to Library"}
          </button>
          <button style={btnDanger} onClick={onClear}>Clear</button>
        </div>
      </div>

      {/* ── Right: preview ── */}
      <div style={{ position: "sticky", top: 20 }}>
        <p style={{ ...sectionTitle, marginBottom: 12 }}>Live Preview</p>
        <CardPreview card={card} skills={state.skills} creatureTypes={state.creatureTypes} />
      </div>
    </div>
  );
}

// ─── Card Library ─────────────────────────────────────────────────────────────

function CardLibrary({ state, onEdit, onDelete }: {
  state: AppState; onEdit: (c: NPCCard) => void; onDelete: (id: string) => void;
}) {
  const [query, setQuery] = useState("");
  const [expanded, setExpanded] = useState<string | null>(null);

  const filtered = useMemo(() => {
    const q = query.toLowerCase();
    if (!q) return state.cards;
    return state.cards.filter(c =>
      c.name.toLowerCase().includes(q) || c.description.toLowerCase().includes(q) ||
      c.tags.some(t => t.toLowerCase().includes(q)));
  }, [state.cards, query]);

  if (state.cards.length === 0) {
    return (
      <div style={{ textAlign: "center", padding: 60, color: "#5a4a3a" }}>
        <div style={{ fontSize: 48, marginBottom: 12 }}>📜</div>
        <p style={{ fontFamily: "'Cinzel', serif", color: "#7a6a4a" }}>Your library is empty. Build your first NPC card.</p>
      </div>
    );
  }

  return (
    <div>
      <input style={{ ...inputBase, marginBottom: 16 }} placeholder="Search library by name, tag, description…"
        value={query} onChange={e => setQuery(e.target.value)} />
      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(300px, 1fr))", gap: 16 }}>
        {filtered.map(card => {
          const types = card.creatureTypeIds.map(id => state.creatureTypes.find(c => c.id === id)).filter(Boolean) as CreatureType[];
          return (
            <div key={card.id} style={{ background: "linear-gradient(160deg, #1c1510 0%, #12100e 100%)", border: "1px solid #3a2f20", borderRadius: 10, overflow: "hidden" }}>
              <div style={{ padding: 16 }}>
                <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start" }}>
                  <div>
                    <h3 style={{ fontFamily: "'Cinzel', serif", color: "#f0deb0", fontSize: 18, margin: 0 }}>{card.name}</h3>
                    <div style={{ display: "flex", gap: 5, marginTop: 2, flexWrap: "wrap" }}>
                      {types.map(t => <span key={t.id} style={{ ...applyFmt(t.format), fontSize: 10 }}>[{t.name}]</span>)}
                    </div>
                    <p style={{ color: "#9a8a6a", fontSize: 11, margin: "4px 0 0" }}>
                      Body {card.body} · Armor {card.armor} · {card.skills.length} skills
                    </p>
                  </div>
                  <div style={{ display: "flex", gap: 6 }}>
                    <button style={btnGhost} onClick={() => onEdit(card)}>Edit</button>
                    <button style={btnDanger} onClick={() => onDelete(card.id)}>✕</button>
                  </div>
                </div>
                {card.tags.length > 0 && (
                  <div style={{ display: "flex", gap: 4, flexWrap: "wrap", marginTop: 8 }}>
                    {card.tags.map(t => (
                      <span key={t} style={{ background: "#1a1208", border: "1px solid #3a2f20", borderRadius: 3, fontSize: 9, color: "#7a6a4a", padding: "1px 5px", fontFamily: "'Cinzel', serif", letterSpacing: "0.08em" }}>{t}</span>
                    ))}
                  </div>
                )}
                <button style={{ background: "none", border: "none", color: "#7a6a4a", cursor: "pointer", fontSize: 11, marginTop: 8, padding: 0, fontFamily: "serif" }}
                  onClick={() => setExpanded(e => e === card.id ? null : card.id)}>
                  {expanded === card.id ? "▲ Hide Preview" : "▼ Show Preview"}
                </button>
              </div>
              {expanded === card.id && (
                <div style={{ padding: "0 16px 16px", display: "flex", justifyContent: "center", overflowX: "auto" }}>
                  <CardPreview card={card} skills={state.skills} creatureTypes={state.creatureTypes} />
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}

// ─── Card Web ─────────────────────────────────────────────────────────────────

type WebAxis = "creatureType" | "tag" | "bodyRange" | "skillCount";

function CardWeb({ state }: { state: AppState }) {
  const [axis, setAxis] = useState<WebAxis>("creatureType");

  const groups = useMemo<Map<string, NPCCard[]>>(() => {
    const map = new Map<string, NPCCard[]>();
    const push = (key: string, card: NPCCard) => {
      if (!map.has(key)) map.set(key, []);
      map.get(key)!.push(card);
    };
    for (const card of state.cards) {
      if (axis === "creatureType") {
        if (card.creatureTypeIds.length === 0) push("Untyped", card);
        else for (const tid of card.creatureTypeIds) push(state.creatureTypes.find(c => c.id === tid)?.name ?? "Unknown", card);
      } else if (axis === "tag") {
        if (card.tags.length === 0) push("Untagged", card);
        else for (const tag of card.tags) push(tag, card);
      } else if (axis === "bodyRange") {
        const b = card.body;
        push(b <= 50 ? "0–50" : b <= 100 ? "51–100" : b <= 200 ? "101–200" : b <= 500 ? "201–500" : "500+", card);
      } else {
        const n = card.skills.length;
        push(n === 0 ? "0 skills" : n <= 3 ? "1–3 skills" : n <= 6 ? "4–6 skills" : "7+ skills", card);
      }
    }
    return map;
  }, [state.cards, state.creatureTypes, axis]);

  if (state.cards.length === 0) {
    return (
      <div style={{ textAlign: "center", padding: 60 }}>
        <p style={{ fontFamily: "'Cinzel', serif", color: "#7a6a4a" }}>Save some cards to view them in the web.</p>
      </div>
    );
  }

  return (
    <div>
      <div style={{ display: "flex", alignItems: "center", gap: 12, marginBottom: 20 }}>
        <label style={{ color: "#9a8a6a", fontSize: 12, fontFamily: "'Cinzel', serif" }}>Organize by:</label>
        <select style={inputSm} value={axis} onChange={e => setAxis(e.target.value as WebAxis)}>
          <option value="creatureType">Creature Type</option>
          <option value="tag">Tag</option>
          <option value="bodyRange">Body Range</option>
          <option value="skillCount">Skill Count</option>
        </select>
      </div>
      <div style={{ overflowX: "auto" }}>
        <div style={{ display: "flex", gap: 28, minWidth: "max-content", alignItems: "flex-start" }}>
          {[...groups.entries()].map(([groupName, cards]) => (
            <div key={groupName} style={{ minWidth: 220 }}>
              <div style={{ fontFamily: "'Cinzel', serif", color: "#c8a96e", fontSize: 12, letterSpacing: "0.12em", textTransform: "uppercase", borderBottom: "1px solid #5a4520", paddingBottom: 8, marginBottom: 12 }}>
                {groupName}
                <span style={{ color: "#5a4520", fontSize: 10, marginLeft: 6 }}>({cards.length})</span>
              </div>
              <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
                {cards.map(card => {
                  const types = card.creatureTypeIds.map(id => state.creatureTypes.find(c => c.id === id)).filter(Boolean) as CreatureType[];
                  return (
                    <div key={card.id} style={{ background: "linear-gradient(160deg, #1c1510 0%, #12100e 100%)", border: "1px solid #3a2f20", borderRadius: 8, padding: "10px 14px" }}>
                      <div style={{ fontFamily: "'Cinzel', serif", color: "#f0deb0", fontSize: 14, marginBottom: 3 }}>{card.name}</div>
                      <div style={{ display: "flex", gap: 4, flexWrap: "wrap" }}>
                        {types.map(t => <span key={t.id} style={{ ...applyFmt(t.format), fontSize: 9 }}>[{t.name}]</span>)}
                      </div>
                      <div style={{ color: "#7a6a4a", fontSize: 10, marginTop: 4 }}>♥ {card.body} ⚔ {card.armor} · {card.skills.length} skills</div>
                      {card.tags.length > 0 && (
                        <div style={{ marginTop: 4, display: "flex", gap: 3, flexWrap: "wrap" }}>
                          {card.tags.map(t => <span key={t} style={{ background: "#1a1208", border: "1px solid #3a2f20", borderRadius: 2, fontSize: 8, color: "#6a5a3a", padding: "1px 4px" }}>{t}</span>)}
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

// ─── Root App ─────────────────────────────────────────────────────────────────

type Tab = "builder" | "library" | "web" | "skills" | "damage" | "creatures";
const TAB_LABELS: { id: Tab; label: string }[] = [
  { id: "builder",   label: "Card Builder" },
  { id: "library",   label: "Library" },
  { id: "web",       label: "Card Web" },
  { id: "skills",    label: "Skills Bank" },
  { id: "damage",    label: "Damage Types" },
  { id: "creatures", label: "Creature Types" },
];

export default function App() {
  const [state, setState] = useState<AppState>(() => {
    const s = loadState();
    if (s.skills.length === 0 && s.damageTypes.length === 0 && s.creatureTypes.length === 0) return seedState;
    return s;
  });
  const [tab, setTab] = useState<Tab>("builder");
  const [editingCard, setEditingCard] = useState<NPCCard | undefined>(undefined);

  const update = useCallback((patch: Partial<AppState>) => {
    setState(s => { const next = { ...s, ...patch }; saveState(next); return next; });
  }, []);

  const saveCard = (card: NPCCard) => {
    const cards = state.cards.find(c => c.id === card.id)
      ? state.cards.map(c => c.id === card.id ? card : c)
      : [...state.cards, card];
    update({ cards });
    setTab("library");
    setEditingCard(undefined);
  };

  return (
    <div style={{ minHeight: "100vh", background: "linear-gradient(170deg, #0e0c09 0%, #0a0806 60%, #0d0b08 100%)", color: "#e8dcc8" }}>
      <header style={{
        background: "linear-gradient(90deg, #0d0b08 0%, #1a1208 50%, #0d0b08 100%)",
        borderBottom: "1px solid #3a2f20", padding: "14px 28px",
        display: "flex", alignItems: "center", justifyContent: "space-between",
        position: "sticky", top: 0, zIndex: 100,
        boxShadow: "0 2px 20px rgba(0,0,0,0.6)",
      }}>
        <div>
          <h1 style={{ fontFamily: "'Cinzel', serif", fontSize: 22, fontWeight: 700, color: "#c8a96e", margin: 0, letterSpacing: "0.08em", textShadow: "0 0 20px rgba(200,169,110,0.3)" }}>
            ⚔ NPC Card Forge
          </h1>
          <p style={{ color: "#5a4a3a", fontSize: 10, margin: 0, letterSpacing: "0.1em" }}>LARP CHARACTER BUILDER</p>
        </div>
        <nav style={{ display: "flex", gap: 4, flexWrap: "wrap" }}>
          {TAB_LABELS.map(t => (
            <button key={t.id} onClick={() => setTab(t.id)} style={{
              background: tab === t.id ? "linear-gradient(135deg, #3a2a10, #5c3d11)" : "transparent",
              border: `1px solid ${tab === t.id ? "#c8a96e" : "#3a2f20"}`,
              borderRadius: 6, color: tab === t.id ? "#f0deb0" : "#7a6a4a",
              padding: "6px 12px", cursor: "pointer", fontFamily: "'Cinzel', serif",
              fontSize: 11, letterSpacing: "0.05em", transition: "all 0.15s",
            }}>
              {t.label}
            </button>
          ))}
        </nav>
      </header>

      <main style={{ padding: "28px 28px 60px", maxWidth: 1400, margin: "0 auto" }}>
        <div style={{ fontFamily: "'Cinzel', serif", fontSize: 13, color: "#7a6a4a", marginBottom: 20, letterSpacing: "0.08em" }}>
          {TAB_LABELS.find(t => t.id === tab)?.label}
          {tab === "builder" && editingCard && <span style={{ color: "#c8a96e" }}> — Editing: {editingCard.name}</span>}
        </div>

        {tab === "builder" && (
          <CardBuilder state={state} onSave={saveCard} editCard={editingCard}
            onClear={() => setEditingCard(undefined)} />
        )}
        {tab === "library" && (
          <CardLibrary state={state}
            onEdit={c => { setEditingCard(c); setTab("builder"); }}
            onDelete={id => update({ cards: state.cards.filter(c => c.id !== id) })} />
        )}
        {tab === "web" && <CardWeb state={state} />}
        {tab === "skills" && <SkillsBank skills={state.skills} onUpdate={skills => update({ skills })} />}
        {tab === "damage" && <DamageTypesBank types={state.damageTypes} onUpdate={dt => update({ damageTypes: dt })} />}
        {tab === "creatures" && (
          <CreatureTypesBank types={state.creatureTypes} onUpdate={ct => update({ creatureTypes: ct })}
            damageTypes={state.damageTypes} skills={state.skills} />
        )}
      </main>
    </div>
  );
}
